package com.cg.project.stepdefination;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.bean.RegistrationPageBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class RegistrationStepStepDefination {

	private WebDriver driver;

	private RegistrationPageBean pageBean;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\HRVERMA\\Desktop\\Module 3\\chromedriver.exe");
		driver=new ChromeDriver();	
	}

	@Given("^User is on JobsWorld Page and accessing RegisterForm on the Browser$")
	public void user_is_on_JobsWorld_Page_and_accessing_RegisterForm_on_the_Browser() throws Throwable {
		driver.get("C:\\Users\\HRVERMA\\Documents\\My Received Files\\3000147_SyedJavedAhmed_Set2\\WebPages\\RegistrationForm.html");
		pageBean = PageFactory.initElements(driver, RegistrationPageBean.class);
	}

	@When("^User is submiting data with invalid entry of 'User Id'$")
	public void user_is_submiting_data_with_invalid_entry_of_User_Id() throws Throwable {
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void alert_box_should_display_the_message_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String expectedAlertMessage ="User Id should not be empty / length be between 5 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	
	@When("^User is submiting data with invalid entry of 'Name'$")
	public void user_is_submiting_data_with_invalid_entry_of_Name() throws Throwable {
	    driver.switchTo().alert().dismiss();
	    pageBean.setUserId("Hrishu10");
	    pageBean.clickSignUp();
	    Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'Name should not be empty and must have alphabet characters only'$")
	public void alert_box_should_display_the_message_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String expectedAlertMessage ="Name should not be empty and must have alphabet characters only";
		String actualAlertMessage2=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage2);
	}
	
	@When("^User is submiting data with invalid entry of 'Password'$")
	public void user_is_submiting_data_with_invalid_entry_of_Password() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void alert_box_should_display_the_message_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		
		String expectedAlertMessage ="Password should not be empty / length be between 7 to 12";
		String actualAlertMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage1);
	}

	@When("^User is submiting data with invalid entry of 'address'$")
	public void user_is_submiting_data_with_invalid_entry_of_address() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.setPassid("Rajput96");
		pageBean.setAddress("ganeshchowk112@@");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'User address must have alphanumeric characters only'$")
	public void alert_box_should_display_the_message_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		String expectedAlertMessage ="User address must have alphanumeric characters only";
		String actualAlertMessage3=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage3);
	}

	@When("^User is submiting data without selecting valid entry of 'country'$")
	public void user_is_submiting_data_without_selecting_valid_entry_of_country() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.setPassid("Rajput96");
		pageBean.setAddress("ganeshchowk112");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'Select your country from the list'$")
	public void alert_box_should_display_the_message_Select_your_country_from_the_list() throws Throwable {
		String expectedAlertMessage="Select your country from the list";
		String actualAlertMessage4=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage4);
	}

	@When("^User is submiting data with invalid entry of 'zipCode'$")
	public void user_is_submiting_data_with_invalid_entry_of_zipCode() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.setPassid("Rajput96");
		pageBean.setAddress("ganeshchowk112");
		pageBean.setCountry("India");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'ZIP code must have numeric characters only'$")
	public void alert_box_should_display_the_message_ZIP_code_must_have_numeric_characters_only() throws Throwable {
		String expectedAlertMessage="ZIP code must have numeric characters only";
		String actualAlertMessage5=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage5);
	}

	@When("^User is submiting data with invalid entry of 'email'$")
	public void user_is_submiting_data_with_invalid_entry_of_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.setPassid("Rajput96");
		pageBean.setAddress("ganeshchowk112");
		pageBean.setCountry("India");
		pageBean.setZip("247663");
		pageBean.setEmail("hrishu.verma1996$gmail.com");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'You have entered an invalid email address!'$")
	public void alert_box_should_display_the_message_You_have_entered_an_invalid_email_address() throws Throwable {
		String expectedAlertMessage="You have entered an invalid email address!";
		String actualAlertMessage6=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage6);
	}

	@When("^User is submiting data with invalid entry of 'sex'$")
	public void user_is_submiting_data_with_invalid_entry_of_sex() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.setPassid("Rajput96");
		pageBean.setAddress("ganeshchowk112");
		pageBean.setCountry("India");
		pageBean.setZip("247663");
		pageBean.setEmail("hrishu.verma1996@gmail.com");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^alert box should display the message 'Please Select gender'$")
	public void alert_box_should_display_the_message_Please_Select_gender() throws Throwable {
		String expectedAlertMessage="Please Select gender";
		String actualAlertMessage7=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage7);
	}

	@When("^User is submitting data with entring valid set of information$")
	public void user_is_submitting_data_with_entring_valid_set_of_information() throws Throwable {
		
		pageBean.setUserId("Hrishu1010");
		pageBean.setUsername("HrishuDev");
		pageBean.setPassid("Rajput96");
		pageBean.setAddress("ganeshchowk112");
		pageBean.setCountry("India");
		pageBean.setZip("247663");
		pageBean.setEmail("hrishu.verma1996@gmail.com");
		pageBean.setSex("Male");
		pageBean.clickSignUp();
		Thread.sleep(2000);
	}

	@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile'$")
	public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile() throws Throwable {
		String expectedAlertMessage="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualAlertMessage8=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage8);
	}

	@After
	public void tearDownStepEnv() {
		driver.switchTo().alert().dismiss();
		driver.close();
	}
}
